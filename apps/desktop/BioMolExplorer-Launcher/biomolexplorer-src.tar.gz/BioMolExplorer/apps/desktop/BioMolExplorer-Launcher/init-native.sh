#!/usr/bin/env bash
# =============================================================================
#  BioMolExplorer - Native Launcher for Linux / macOS
#  Called by Electron. Manages extraction, Miniconda, Conda env and services.
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_TAR="$SCRIPT_DIR/biomolexplorer-src.tar.gz"

# Electron does not load ~/.bashrc, so common directories are injected into PATH.
_prepend_path() { case ":$PATH:" in *":$1:"*) ;; *) export PATH="$1:$PATH" ;; esac; }
for _nd in "$HOME/.local/bin" "$HOME/.biomolexplorer/miniconda/bin" \
           "$HOME/miniconda3/bin" "$HOME/anaconda3/bin" "/usr/local/bin"; do
  [ -d "$_nd" ] && _prepend_path "$_nd"
done
unset -f _prepend_path 2>/dev/null; unset _nd

# Also pick up any PATH customization the user added manually to their shell rc
# files (this is how most people add DOCK6/Chimera to PATH after a manual
# install, per our own install instructions). We can't just `source ~/.bashrc`
# because on most distros it returns immediately for non-interactive shells
# (the "case $- in *i*) ;; *) return;; esac" guard at its top), so instead we
# pull out only the PATH-related lines and evaluate those.
for _rc in "$HOME/.bashrc" "$HOME/.profile" "$HOME/.bash_profile" "$HOME/.bash_aliases"; do
  [ -f "$_rc" ] || continue
  while IFS= read -r _line; do
    eval "$_line" 2>/dev/null || true
  done < <(grep -E '^[[:space:]]*(export[[:space:]]+)?PATH=' "$_rc" 2>/dev/null)
done
unset _rc _line

# Activate nvm if already installed
export NVM_DIR="$HOME/.biomolexplorer/nvm"
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh" >/dev/null 2>&1 || true

INSTALL_DIR="$HOME/.biomolexplorer"
APP_DIR="$INSTALL_DIR/app"
CONDA_DIR="$INSTALL_DIR/miniconda"
CONDA_ENV_NAME="BioMolExplorer"
PORT=3000

# -------- Log helpers --------
step() { printf '  [..] %s\n' "$1"; }
ok()   { printf '  [OK] %s\n' "$1"; }
warn() { printf '  [!!] %s\n' "$1"; }
fail() {
  printf '  [FAIL] %s\n' "$1"
  [ -n "$2" ] && printf '  [HINT] %s\n' "$2"
  exit 1
}

banner() {
  printf '\n'
  printf '  +--------------------------------------------------+\n'
  printf '  |      BioMolExplorer 2.0  --  Native Launcher     |\n'
  printf '  |        Molecular Analysis Platform                |\n'
  printf '  +--------------------------------------------------+\n'
  printf '\n'
}

# Download wrapper: uses curl or wget
_download() {
  local url="$1" dest="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$url" -o "$dest"
  elif command -v wget >/dev/null 2>&1; then
    wget -q "$url" -O "$dest"
  else
    fail "No download tool found (curl/wget)." \
      "Reinstall BioMolExplorer via .deb to fix dependencies."
  fi
}

# HTTP health check wrapper
_http_ok() {
  local url="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -s --max-time 2 "$url" >/dev/null 2>&1
  else
    wget -q --timeout=2 "$url" -O /dev/null >/dev/null 2>&1
  fi
}

# =============================================================================
#  [1/6] Extract source code (first run) or update it (when the .deb is newer)
# =============================================================================

# Fingerprint of the packaged source tarball. Changes on every rebuild, so a
# freshly installed .deb is always detected as new (even at the same version).
_bundled_id() {
  [ -f "$SRC_TAR" ] || return 1
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$SRC_TAR" 2>/dev/null | cut -c1-16
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$SRC_TAR" 2>/dev/null | cut -c1-16
  else
    wc -c < "$SRC_TAR" 2>/dev/null | tr -d ' '   # fallback: size in bytes
  fi
}

# Reads the app version bundled inside the source tarball (for display only).
_bundled_version() {
  [ -f "$SRC_TAR" ] || return 1
  local top
  top=$(tar -tzf "$SRC_TAR" 2>/dev/null | head -1 | cut -d/ -f1)
  [ -n "$top" ] || return 1
  tar -xzOf "$SRC_TAR" "$top/package.json" 2>/dev/null \
    | grep -m1 '"version"' \
    | sed -E 's/.*"version"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/'
}

extract_source() {
  local installed_id="" bundled_id="" ver=""
  [ -f "$APP_DIR/.buildid" ] && installed_id=$(cat "$APP_DIR/.buildid" 2>/dev/null)
  bundled_id=$(_bundled_id) || bundled_id=""
  ver=$(_bundled_version) || ver=""

  # No bundled source in the package: keep any existing install, else fail.
  if [ ! -f "$SRC_TAR" ]; then
    [ -f "$APP_DIR/package.json" ] && { ok "Installation found at $APP_DIR"; return; }
    fail "Package not found: $SRC_TAR" "Try reinstalling BioMolExplorer via .deb."
  fi

  # First run: full extraction.
  if [ ! -f "$APP_DIR/package.json" ]; then
    step "Installing BioMolExplorer${ver:+ v$ver} at $INSTALL_DIR..."
    mkdir -p "$APP_DIR"
    tar -xzf "$SRC_TAR" -C "$APP_DIR" --strip-components=1 \
      || fail "Failed to extract source code." "The file may be corrupted. Reinstall the .deb."
    printf '%s\n' "$bundled_id" > "$APP_DIR/.buildid"
    printf '%s\n' "$ver"        > "$APP_DIR/.version"
    ok "Source code installed!"
    return
  fi

  # Same build already installed: nothing to do.
  if [ -n "$bundled_id" ] && [ "$installed_id" = "$bundled_id" ]; then
    ok "Installation up to date at $APP_DIR${ver:+ (v$ver)}"
    return
  fi

  # Different build (or unknown): refresh the code over the existing install.
  # datasets/, resultados/, apps/api/uploads/ and node_modules are NOT in the
  # tarball, so this overlay never touches user data or installed dependencies.
  step "Updating BioMolExplorer code${ver:+ (v$ver)}..."
  find "$APP_DIR" -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true
  rm -rf "$APP_DIR/apps/web/.next" 2>/dev/null || true
  tar -xzf "$SRC_TAR" -C "$APP_DIR" --strip-components=1 \
    || fail "Failed to update source code." "The file may be corrupted. Reinstall the .deb."
  printf '%s\n' "$bundled_id" > "$APP_DIR/.buildid"
  printf '%s\n' "$ver"        > "$APP_DIR/.version"
  NEEDS_NPM_INSTALL=1   # a code update may change JS deps -> force a sync
  ok "Updated${ver:+ to v$ver}!"
}

# =============================================================================
#  [2/6] Verify required external tools: Chimera, DOCK6, DMS.
#
#        All three are checked together (instead of stopping at the first missing
#        one) so the user gets a single, complete list of what to install.
#
#        None of the three are installed by this script - they are licensed
#        (Chimera, DOCK6) or user-built (DMS) third-party tools. Each is only
#        *checked*; a missing/broken one aborts startup with install hints.
# =============================================================================

# True iff <bin> can actually produce a molecular surface: run it on a tiny PDB
# from a scratch dir that has NO local `radii` file, so success proves its
# compiled-in radii/dmsd paths resolve - exactly the condition the docking
# pipeline needs (it invokes dms from the per-job surface/ directory). A `dms`
# that merely exists but was built/installed wrong (e.g. missing
# /usr/local/lib/dms/dmsd) would still pass a plain `command -v` check but fail
# here.
_dms_functional() {
  local bin="$1" work rc=1
  [ -x "$bin" ] || return 1
  work="$(mktemp -d 2>/dev/null)" || return 1
  cat > "$work/_probe.pdb" <<'PDB'
ATOM      1  N   ALA A   1      11.104   6.134  -6.504  1.00  0.00           N
ATOM      2  CA  ALA A   1      11.639   6.071  -5.147  1.00  0.00           C
ATOM      3  C   ALA A   1      13.114   6.461  -5.140  1.00  0.00           C
ATOM      4  O   ALA A   1      13.706   6.617  -6.207  1.00  0.00           O
ATOM      5  CB  ALA A   1      10.847   7.036  -4.267  1.00  0.00           C
TER
END
PDB
  if ( cd "$work" && "$bin" _probe.pdb -a -o _probe.dms ) >/dev/null 2>&1 \
     && [ -s "$work/_probe.dms" ]; then
    rc=0
  fi
  rm -rf "$work"
  return $rc
}

check_external_tools() {
  local missing=()

  step "Checking UCSF Chimera..."
  if command -v chimera >/dev/null 2>&1; then
    ok "Chimera found: $(command -v chimera)"
  else
    warn "Chimera not found. The 'chimera' command must be resolvable via PATH (wherever it's installed)."
    missing+=("Chimera")
  fi

  step "Checking DOCK6..."
  # Mirrors the resolution order used by the backend (apps/python-service/app.py):
  # PATH -> $DOCK6_PATH env var -> ~/progs/dock6/ fallback.
  if command -v dock6 >/dev/null 2>&1 \
    || { [ -n "$DOCK6_PATH" ] && [ -x "$DOCK6_PATH/bin/dock6" ]; } \
    || [ -x "$HOME/progs/dock6/bin/dock6" ]; then
    ok "DOCK6 found."
  else
    warn "DOCK6 not found. Expected 'dock6' on PATH, \$DOCK6_PATH/bin/dock6, or $HOME/progs/dock6/bin/dock6."
    missing+=("DOCK6")
  fi

  step "Checking DMS (molecular-surface generator)..."
  # dms forks+execs a companion `dmsd` and reads a `radii` table via paths baked
  # in at compile time, so a plain `command -v dms` isn't enough to trust it -
  # _dms_functional actually generates a surface to confirm those paths resolve.
  local dms_bin
  dms_bin="$(command -v dms 2>/dev/null)"
  if [ -n "$dms_bin" ] && _dms_functional "$dms_bin"; then
    ok "DMS found: $dms_bin"
  else
    warn "DMS not found (or not working). The 'dms' command must be resolvable via PATH (wherever it's installed)."
    missing+=("DMS")
  fi

  [ ${#missing[@]} -eq 0 ] && { ok "All required external tools are present."; return; }

  printf '\n'
  warn "Missing required tool(s): ${missing[*]}"
  for dep in "${missing[@]}"; do
    case "$dep" in
      Chimera)
        printf '        - Chimera: download the .bin installer at https://www.rbvi.ucsf.edu/chimera/download.html,\n'
        printf '          run it, and make sure the "chimera" command ends up on your PATH.\n'
        ;;
      DOCK6)
        printf '        - DOCK6: request/download it at http://dock.compbio.ucsf.edu/, build it, then either add\n'
        printf '          its bin/ folder to PATH, set the DOCK6_PATH environment variable to the install\n'
        printf '          directory, or install it at ~/progs/dock6/.\n'
        ;;
      DMS)
        printf '        - DMS: see https://www.cgl.ucsf.edu/chimera/docs/UsersGuide/dms.html for build/install instructions.\n'
        ;;
    esac
  done
  printf '\n'

  # Build a compact one-line hint (main.js only reads the first [HINT] line
  # for the error screen); the full instructions above stay in the logs.
  local hint=""
  for dep in "${missing[@]}"; do
    case "$dep" in
      Chimera) hint="${hint}${hint:+ | }Chimera: rbvi.ucsf.edu/chimera/download.html" ;;
      DOCK6)   hint="${hint}${hint:+ | }DOCK6: dock.compbio.ucsf.edu" ;;
      DMS)     hint="${hint}${hint:+ | }DMS: www.cgl.ucsf.edu/chimera/docs/UsersGuide/dms.html" ;;
    esac
  done

  fail "Required external tool(s) not found: ${missing[*]}." \
    "${hint} — see technical details below for full instructions."
}

# =============================================================================
#  [3/6] Install Miniconda (first run only)
# =============================================================================
install_miniconda() {
  if [ -f "$CONDA_DIR/bin/conda" ]; then
    ok "Miniconda already installed."
    return
  fi
  step "Downloading Miniconda..."
  local url
  case "$(uname -sm)" in
    "Linux x86_64")  url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" ;;
    "Linux aarch64") url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-aarch64.sh" ;;
    "Darwin x86_64") url="https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-x86_64.sh" ;;
    "Darwin arm64")  url="https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-arm64.sh" ;;
    *) fail "Unsupported architecture: $(uname -sm)" ;;
  esac
  local installer="/tmp/biomol-miniconda-$$.sh"
  _download "$url" "$installer" \
    || fail "Failed to download Miniconda." "Check your internet connection."
  bash "$installer" -b -p "$CONDA_DIR" \
    || fail "Failed to install Miniconda."
  rm -f "$installer"
  ok "Miniconda installed at $CONDA_DIR!"
}

# =============================================================================
#  [4/6] Create Conda environment with scientific dependencies (first run only)
#        Re-synced automatically whenever requirements.yml changes, so an
#        already-existing environment never silently drifts (e.g. missing a
#        package that was added to requirements.yml after the env was built).
# =============================================================================

# Fingerprint of requirements.yml, used to detect drift on already-created envs.
_req_id() {
  local f="$1"
  [ -f "$f" ] || return 1
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$f" 2>/dev/null | cut -c1-16
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$f" 2>/dev/null | cut -c1-16
  else
    wc -c < "$f" 2>/dev/null | tr -d ' '   # fallback: size in bytes
  fi
}

setup_conda_env() {
  source "$CONDA_DIR/etc/profile.d/conda.sh"
  # Accept Anaconda Terms of Service (required since 2024 in non-interactive mode)
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main 2>/dev/null || true
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r 2>/dev/null || true

  local req_file="$APP_DIR/requirements.yml"
  [ ! -f "$req_file" ] && fail "requirements.yml file not found: $req_file"
  local CONDA_ENV_DIR="$CONDA_DIR/envs/$CONDA_ENV_NAME"
  local req_id_file="$CONDA_ENV_DIR/.reqid"
  local current_id; current_id=$(_req_id "$req_file") || current_id=""
  local stored_id=""
  [ -f "$req_id_file" ] && stored_id=$(cat "$req_id_file" 2>/dev/null)

  if conda env list | grep -q "^$CONDA_ENV_NAME "; then
    # Env exists but requirements.yml changed since it was built (or it predates
    # the .reqid marker, which also covers installs affected by earlier bugs):
    # sync it instead of silently leaving it stale.
    if [ -z "$current_id" ] || [ "$stored_id" = "$current_id" ]; then
      ok "Conda environment '$CONDA_ENV_NAME' already exists and is up to date."
      return
    fi
    step "Syncing Conda environment with updated requirements.yml..."
    warn "This step may take a few minutes..."
    conda env update -f "$req_file" --prune \
      || fail "Failed to update Conda environment." "Check your internet connection and try again."
    printf '%s\n' "$current_id" > "$req_id_file"
    ok "Environment '$CONDA_ENV_NAME' synced!"
    return
  fi

  step "Creating Conda environment with scientific dependencies..."
  warn "This step may take 5 to 15 minutes on the first run..."
  conda env create -f "$req_file" -y \
    || fail "Failed to create Conda environment." "Check your internet connection and try again."
  printf '%s\n' "$current_id" > "$req_id_file"
  ok "Environment '$CONDA_ENV_NAME' created!"
}

# =============================================================================
#  [4.5/6] Install Node.js via nvm if missing (no sudo)
# =============================================================================
install_node() {
  # Check if node >= 18 is already in PATH (system or nvm)
  if command -v node >/dev/null 2>&1; then
    local ver; ver=$(node --version | sed 's/v//' | cut -d. -f1)
    [ "$ver" -ge 18 ] && { ok "Node.js $(node --version) found."; return; }
  fi

  step "Installing Node.js 20 via nvm..."
  export NVM_DIR="$HOME/.biomolexplorer/nvm"
  mkdir -p "$NVM_DIR"
  local nvm_install="/tmp/nvm-install-$$.sh"
  _download "https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh" "$nvm_install" \
    || fail "Failed to download nvm." "Check your internet connection."
  PROFILE=/dev/null bash "$nvm_install" >/dev/null 2>&1
  rm -f "$nvm_install"
  [ -s "$NVM_DIR/nvm.sh" ] || fail "Failed to install nvm." "Check your internet connection."
  source "$NVM_DIR/nvm.sh"
  nvm install 20 \
    || fail "Failed to install Node.js 20." "Check your internet connection."
  ok "Node.js $(node --version) installed via nvm!"
}

# =============================================================================
#  [5/6] Install JavaScript dependencies (first run only)
# =============================================================================
setup_npm() {
  if [ -d "$APP_DIR/node_modules" ] && [ "${NEEDS_NPM_INSTALL:-0}" != "1" ]; then
    ok "JavaScript dependencies already installed."
    return
  fi
  command -v node >/dev/null 2>&1 \
    || fail "Node.js not found." "Reinstall BioMolExplorer via .deb to fix dependencies."
  local node_ver
  node_ver=$(node --version | sed 's/v//' | cut -d. -f1)
  [ "$node_ver" -lt 18 ] && fail "Node.js $node_ver detected. Node.js 18+ is required." \
    "Reinstall BioMolExplorer via .deb to update Node.js."
  local npm_bin
  npm_bin=$(command -v npm 2>/dev/null) \
    || fail "npm not found." "Reinstall BioMolExplorer via .deb to fix dependencies."
  step "Installing JavaScript dependencies..."
  (cd "$APP_DIR" && "$npm_bin" install) \
    || fail "Failed to install JavaScript dependencies." "Check your internet connection."
  ok "JavaScript dependencies installed!"
}

# =============================================================================
#  Integrate icon into user's system (first run only)
# =============================================================================
integrate_desktop() {
  local icon_src="$APP_DIR/apps/desktop/wrapper/assets/icons/256x256.png"
  local icon_dst="$HOME/.local/share/icons/hicolor/256x256/apps/biomolexplorer.png"

  [ -f "$icon_dst" ] && return
  [ ! -f "$icon_src" ] && return

  step "Integrating icon into the system..."
  mkdir -p "$(dirname "$icon_dst")"
  cp "$icon_src" "$icon_dst"
  gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true
  ok "Icon integrated!"
}

# =============================================================================
#  [6/6] Start the 3 native services
# =============================================================================
start_services() {
  local CONDA_ENV_DIR="$CONDA_DIR/envs/$CONDA_ENV_NAME"
  local PYTHON_BIN="$CONDA_ENV_DIR/bin/python"

  [ -f "$PYTHON_BIN" ] || fail "Python not found at $PYTHON_BIN." \
    "The conda environment may not have been created. Delete ~/.biomolexplorer and reopen the app."

  # Manually activate conda environment (without relying on conda activate in subshell)
  export CONDA_PREFIX="$CONDA_ENV_DIR"
  export CONDA_DEFAULT_ENV="$CONDA_ENV_NAME"
  export PATH="$CONDA_ENV_DIR/bin:$PATH"
  export LD_LIBRARY_PATH="$CONDA_ENV_DIR/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

  local NPM_BIN
  NPM_BIN=$(command -v npm 2>/dev/null) || fail "npm not found in PATH."

  local LOG_DIR="$INSTALL_DIR/logs"
  mkdir -p "$LOG_DIR"

  step "Freeing ports 3000, 3001 and 5000..."
  fuser -k -9 3000/tcp 3001/tcp 5000/tcp >/dev/null 2>&1 || true

  step "Starting Flask (port 5000)..."
  (cd "$APP_DIR/apps/python-service" && "$PYTHON_BIN" app.py) > "$LOG_DIR/flask.log" 2>&1 &
  local FLASK_PID=$!

  step "Starting Node.js API (port 3001)..."
  (cd "$APP_DIR" && "$NPM_BIN" run start --workspace=api) > "$LOG_DIR/api.log" 2>&1 &

  step "Waiting for backends to be ready..."
  local count=0
  while [ $count -lt 90 ]; do
    sleep 1
    count=$((count + 1))

    # Check if Flask died with an error
    if ! kill -0 "$FLASK_PID" 2>/dev/null; then
      warn "Flask exited unexpectedly. Last log lines:"
      tail -20 "$LOG_DIR/flask.log" | while IFS= read -r line; do printf '  [flask] %s\n' "$line"; done
      fail "Flask failed to start." "Check the log at $LOG_DIR/flask.log"
    fi

    FLASK_OK=$(_http_ok http://127.0.0.1:5000/pdb_files && echo 1 || echo 0)
    NODE_OK=$(_http_ok http://127.0.0.1:3001/api/files/list/PDB && echo 1 || echo 0)
    if [ "$FLASK_OK" = "1" ] && [ "$NODE_OK" = "1" ]; then
      ok "Backends ready!"
      break
    fi
  done

  step "Starting Next.js (port 3000)..."
  (cd "$APP_DIR" && "$NPM_BIN" run dev --workspace=web) &

  count=0
  while true; do
    sleep 2
    count=$((count + 2))
    _http_ok "http://localhost:$PORT" && break
    [ "$count" -ge 120 ] && fail "Frontend took too long to respond." \
      "Check the terminal logs for more details."
    printf '  ... Next.js starting %ds / 120s\n' "$count"
  done

  printf '  [OK] BioMolExplorer ready!\n'
  wait
}

# =============================================================================
#  MAIN
# =============================================================================
banner
printf '  [INFO] Mode: Native (Conda + Node.js)\n\n'

printf '  [1/6] Checking installation...\n'
extract_source
printf '\n'

printf '  [2/6] Checking external tools (Chimera, DOCK6) and preparing DMS...\n'
check_external_tools
printf '\n'

printf '  [3/6] Checking Miniconda...\n'
install_miniconda
printf '\n'

printf '  [4/6] Setting up scientific environment...\n'
setup_conda_env
printf '\n'

printf '  [4.5/6] Checking Node.js...\n'
install_node
printf '\n'

printf '  [5/6] Installing JavaScript dependencies...\n'
setup_npm
printf '\n'

printf '  [6/6] Starting services...\n'
integrate_desktop
start_services