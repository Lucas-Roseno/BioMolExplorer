# BioMolExplorer - Desktop Environment & Distribution

This directory contains all the instructions to generate a distributable Desktop interface for BioMolExplorer end users.

---

## Directory Structure

```text
desktop/
├── BioMolExplorer-Launcher/        # Auxiliary files bundled inside the .deb
│   ├── biomolexplorer-src.tar.gz   # Compressed source code (generated automatically)
│   └── init-native.sh              # Native Engine for Linux/macOS (Conda + Node.js)
│
└── wrapper/                        # Electron executable source code
    ├── main.js                     # Main logic (splash screen + bridge to init-native.sh)
    ├── package.json                # Dependencies and electron-builder configuration
    ├── assets/                     # Icons (.png for Linux, .icns for Mac)
    ├── scripts/
    │   └── pack-source.js          # Generates biomolexplorer-src.tar.gz
    └── dist/                       # electron-builder output (.deb, .dmg)
```

---

## Platform Status

| Platform | Mode | Script | Status |
|---|---|---|---|
| Linux | Native (Conda + Node.js) | `init-native.sh` | ✅ Implemented and working |
| macOS | Native (Conda + Node.js) | `init-native.sh` | 🟡 Script ready, not tested on Mac |

> The currently active and distributed build is **`linux-native`**.

---

## Current Distribution Mode: Native (Conda + Node.js)

The current mode is **Native**, without Docker. The launcher automatically installs Miniconda, Node.js and the scientific environment on the user's machine. The user only needs to install the `.deb` and open the application.

> Miniconda, Node.js, RDKit, OpenBabel, Vina, PyMOL and Flask are installed automatically on the first run.
>
> **Exception:** UCSF Chimera and DOCK6 are licensed third-party tools that cannot be bundled/redistributed, so the user must install them manually and make sure they're on `PATH` (see [userguide-linux-en.md](userguide-linux-en.md#requirements)). `init-native.sh` checks for Chimera, DOCK6 and DMS together on every launch (step `[2/6]`) and refuses to start the app if any is missing, showing exactly which one(s) need to be installed. DMS ships bundled with the source and normally passes this check automatically (precompiled binary, or auto-compiled on demand).

---

## Developer Guide: Generating a New Release

### Full Build (single command)

Syncs the version, generates the tarball and compiles the `.deb` in a single command:

```bash
cd apps/desktop/wrapper

# Linux (only active mode currently)
npm run build:linux-native

# macOS — script ready, requires a Mac machine to build
# npm run build:mac-native
```

Internally, `build:linux-native` runs:
1. `npm run sync-version` → syncs the version with the root `package.json`
2. `node scripts/pack-source.js` → generates `BioMolExplorer-Launcher/biomolexplorer-src.tar.gz`
3. `electron-builder --linux deb` → compiles Electron and generates the `.deb` in `dist/`

---

### Package Output

```text
wrapper/dist/biomolexplorer_amd64.deb   ← only artifact generated
```

The `.deb` already contains everything the user needs:
- The Electron executable (graphical interface)
- The `init-native.sh` (initialization engine)
- The `biomolexplorer-src.tar.gz` (source code extracted on first run)

---

## Installing the Generated `.deb`

After the build finishes, install the package with `apt`, which **automatically resolves the system dependencies** (`curl`, `psmisc`). Run this from the repository root:

```bash
sudo apt install ./apps/desktop/wrapper/dist/biomolexplorer_amd64.deb
```

> Prefer `apt install ./file.deb` over `sudo dpkg -i file.deb` — `apt` pulls in missing dependencies on its own, whereas `dpkg -i` would require a separate `sudo apt-get install -f`.

### Updating after a code change

Just rebuild and reinstall the `.deb`. On the next launch the launcher compares the packaged build with the installed one and, when they differ, refreshes the installed source automatically. User data (uploads, datasets, results) and the Conda environment are preserved, so the update is quick.